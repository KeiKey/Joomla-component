DROP TABLE IF EXISTS `#__transaction`;
DROP TABLE IF EXISTS `#__transactiontype`;