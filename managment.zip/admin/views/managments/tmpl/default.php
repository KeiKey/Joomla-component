<?php
defined('_JEXEC') or die('Restricted Access');
echo "this is from the views/managments/tmpl/default.php";
echo $this->transaction;
?>