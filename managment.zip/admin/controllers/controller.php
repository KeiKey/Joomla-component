<?php

defined('_JEXEC') or die('Restricted access');

class ManagmentController extends JControllerForm
{
    protected $default_view = 'managment';
}